<template>
    <div>
        <h1>THE MONEY!</h1>
        <p>Money, money, money, moooneeyyy $ $ $ $</p>
    </div>
</template>