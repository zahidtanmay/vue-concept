<template>
    <div id="user-edit">
        <h2>You may edit the user here</h2>
        <p>Edit me</p>
    </div>
</template>

<style>
    #user-edit{
        background-color: cadetblue;
        padding: 25px;
        width: 50%;
        display: inline-block;
    }
</style>