<template>
    <div id="user-details">
        <h2>You may view user details here</h2>
        <p>Many details</p>
    </div>
</template>

<style>
    #user-details{
        background-color: blueviolet;
        padding: 25px;
        width: 50%;
        display: inline-block;
        float: left;
    }
</style>